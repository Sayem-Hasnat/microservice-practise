package com.tnpay.financialapiintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancialApiIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
