package com.tnpay.financialapiintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancialApiIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancialApiIntegrationApplication.class, args);
	}

}
