package com.tnpay.fraudchecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudCheckerApplication.class, args);
	}

}
