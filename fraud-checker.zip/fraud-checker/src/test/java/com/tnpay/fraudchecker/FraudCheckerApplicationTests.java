package com.tnpay.fraudchecker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudCheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
